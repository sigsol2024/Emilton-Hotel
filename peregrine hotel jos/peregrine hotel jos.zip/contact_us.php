<?php
/**
 * Contact Us Page - Dynamic Content
 * Peregrine Hotel Rayfield
 */

require_once __DIR__ . '/includes/content-loader.php';

// Load site settings
$siteName = getSiteSetting('site_name', 'Peregrine Hotel Rayfield');
$footerAddress = getSiteSetting('footer_address', '12 Rayfield Avenue,<br/>Jos, Plateau State,<br/>Nigeria');
$footerPhone = getSiteSetting('footer_phone', '+234 800 123 4567');
$footerEmail = getSiteSetting('footer_email', 'reservations@peregrinehotel.com');
$socialMediaJson = getSiteSetting('social_media_json', '[]');
$socialMediaList = json_decode($socialMediaJson, true) ?: [];
$googleMapsApiKey = getSiteSetting('google_maps_api_key', '');

// Load page sections
$pageTitle = getPageSection('contact', 'page_title', 'Get in Touch');
$pageSubtitle = getPageSection('contact', 'page_subtitle', 'Experience luxury in the heart of Jos. Reach out for reservations, events, or general inquiries.');
$contactAddress = getPageSection('contact', 'contact_address', $footerAddress);
$reservationsPhone = getPageSection('contact', 'reservations_phone', $footerPhone);
$eventsEmail = getPageSection('contact', 'events_email', $footerEmail);
?>
<!DOCTYPE html>
<html class="light" lang="en">
<head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<title>Contact Us - <?= e($siteName) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,200..800;1,200..800&amp;display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;display=swap" rel="stylesheet"/>
<script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
<script id="tailwind-config">
      tailwind.config = {
        darkMode: "class",
        theme: {
          extend: {
            colors: {
              "primary": "#1754cf",
              "background-light": "#ffffff",
              "background-dark": "#111621",
              "neutral-subtle": "#f9fafb",
            },
            fontFamily: {
              "display": ["Plus Jakarta Sans", "sans-serif"]
            },
            borderRadius: {
                "DEFAULT": "0.375rem", 
                "lg": "0.5rem", 
                "xl": "0.75rem", 
                "full": "9999px"
            },
          },
        },
      }
    </script>
<style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
    </style>
</head>
<body class="bg-background-light dark:bg-background-dark text-[#1f2937] dark:text-[#f3f4f6]">
<?php require_once __DIR__ . '/includes/header.php'; ?>

<main class="flex-grow mt-20">
<!-- Page Header -->
<div class="relative bg-neutral-subtle dark:bg-[#1a202c] py-16 sm:py-24">
<div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
<h1 class="text-4xl font-light tracking-tight text-gray-900 dark:text-white sm:text-5xl lg:text-6xl"><?= e($pageTitle) ?></h1>
<p class="mt-4 text-lg leading-8 text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
    <?= e($pageSubtitle) ?>
</p>
<div class="mt-8 flex justify-center">
<nav aria-label="Breadcrumb" class="flex">
<ol class="flex items-center space-x-2 text-sm text-gray-500 dark:text-gray-400" role="list">
<li><a class="hover:text-amber-700" href="index.php">Home</a></li>
<li><span class="material-symbols-outlined !text-[14px] pt-1">chevron_right</span></li>
<li><span class="font-medium text-gray-900 dark:text-white">Contact</span></li>
</ol>
</nav>
</div>
</div>
</div>

<!-- Split Layout: Info & Form -->
<div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
<div class="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24">
<!-- Left Column: Contact Info -->
<div class="flex flex-col justify-between h-full">
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-1 gap-12">
<!-- Address -->
<div>
<div class="flex items-center gap-3 mb-4 text-amber-700">
<span class="material-symbols-outlined !text-[28px] text-amber-700">location_on</span>
<h3 class="text-2xl font-light text-gray-900 dark:text-white">Visit Us</h3>
</div>
<p class="text-base leading-relaxed text-gray-600 dark:text-gray-400 mb-4">
    <?= strip_tags($contactAddress) ?>
</p>
<a class="inline-flex items-center text-sm font-semibold text-amber-700 hover:text-amber-600 transition-colors" href="https://www.google.com/maps/search/?api=1&query=<?= urlencode(strip_tags($contactAddress)) ?>" target="_blank">
    Get Directions <span class="material-symbols-outlined !text-[18px] ml-1">arrow_forward</span>
</a>
</div>
<!-- Contact Methods -->
<div>
<div class="flex items-center gap-3 mb-4 text-amber-700">
<span class="material-symbols-outlined !text-[28px] text-amber-700">call</span>
<h3 class="text-2xl font-light text-gray-900 dark:text-white">Contact</h3>
</div>
<div class="space-y-3">
<div class="flex flex-col">
<span class="text-sm font-medium text-gray-500 uppercase tracking-wider mb-1">RESERVATIONS</span>
<a class="text-lg text-gray-900 dark:text-white hover:text-amber-700 transition-colors" href="tel:<?= e($reservationsPhone) ?>"><?= e($reservationsPhone) ?></a>
</div>
<div class="flex flex-col">
<span class="text-sm font-medium text-gray-500 uppercase tracking-wider mb-1">EVENTS &amp; SALES</span>
<a class="text-lg text-gray-900 dark:text-white hover:text-amber-700 transition-colors" href="mailto:<?= e($eventsEmail) ?>"><?= e($eventsEmail) ?></a>
</div>
</div>
</div>
</div>
<!-- Socials -->
<?php if (!empty($socialMediaList)): ?>
<div class="mt-12 lg:mt-0 pt-12 border-t border-gray-100 dark:border-gray-800">
<h4 class="text-sm font-medium text-gray-900 dark:text-white mb-6">Follow our journey</h4>
<div class="flex gap-6">
<?php foreach ($socialMediaList as $social): 
    if (!empty($social['icon']) && !empty($social['url'])): ?>
<a class="text-gray-400 hover:text-amber-700 transition-colors" href="<?= htmlspecialchars($social['url'], ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener noreferrer">
    <?php if ($social['icon'] === 'facebook'): ?>
        <span class="sr-only">Facebook</span>
        <svg aria-hidden="true" class="h-6 w-6" fill="currentColor" viewbox="0 0 24 24">
        <path clip-rule="evenodd" d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" fill-rule="evenodd"></path>
        </svg>
    <?php elseif ($social['icon'] === 'instagram'): ?>
        <span class="sr-only">Instagram</span>
        <svg aria-hidden="true" class="h-6 w-6" fill="currentColor" viewbox="0 0 24 24">
        <path clip-rule="evenodd" d="M12.315 2c2.43 0 2.784.013 3.808.06 1.064.049 1.791.218 2.427.465a4.902 4.902 0 011.772 1.153 4.902 4.902 0 011.153 1.772c.247.636.416 1.363.465 2.427.048 1.067.06 1.407.06 4.123v.08c0 2.643-.012 2.987-.06 4.043-.049 1.064-.218 1.791-.465 2.427a4.902 4.902 0 01-1.153 1.772 4.902 4.902 0 01-1.772 1.153c-.636.247-1.363.416-2.427.465-1.067.048-1.407.06-4.123.06h-.08c-2.643 0-2.987-.012-4.043-.06-1.064-.049-1.791-.218-2.427-.465a4.902 4.902 0 01-1.772-1.153 4.902 4.902 0 01-1.153-1.772c-.247-.636-.416-1.363-.465-2.427-.047-1.024-.06-1.379-.06-3.808v-.63c0-2.43.013-2.784.06-3.808.049-1.064.218-1.791.465-2.427a4.902 4.902 0 011.153-1.772 4.902 4.902 0 011.772-1.153c.636-.247 1.363-.416 2.427-.465 1.067-.047 1.407-.06 3.808-.06zM12 5.352c-3.632 0-4.095.013-5.526.078-1.226.056-1.892.274-2.333.445-.584.227-1.002.498-1.442.938-.44.44-.71.858-.938 1.442-.17.441-.389 1.107-.445 2.333-.065 1.431-.078 1.894-.078 5.526s.013 4.095.078 5.526c.056 1.226.274 1.892.445 2.333.227.584.498 1.002.938 1.442.44.44.858.71 1.442.938.441.17 1.107.389 2.333.445 1.431.065 1.894.078 5.526.078s4.095-.013 5.526-.078c1.226-.056 1.892-.274 2.333-.445.584-.227 1.002-.498 1.442-.938.44-.44.71-.858.938-1.442.17-.441.389-1.107.445-2.333.065-1.431.078-1.894.078-5.526s-.013-4.095-.078-5.526c-.056-1.226-.274-1.892-.445-2.333-.227-.584-.498-1.002-.938-1.442-.44-.44-.858-.71-1.442-.938-.441-.17-1.107-.389-2.333-.445-1.431-.065-1.894-.078-5.526-.078zM12 8.448a3.552 3.552 0 100 7.104 3.552 3.552 0 000-7.104zm0 1.63a1.922 1.922 0 110 3.844 1.922 1.922 0 010-3.844zM18.895 6.33a1.086 1.086 0 11-2.172 0 1.086 1.086 0 012.172 0z" fill-rule="evenodd"></path>
        </svg>
    <?php else: ?>
        <span class="material-symbols-outlined text-2xl"><?= htmlspecialchars($social['icon'], ENT_QUOTES, 'UTF-8') ?></span>
    <?php endif; ?>
</a>
<?php endif; 
endforeach; ?>
</div>
</div>
<?php endif; ?>
</div>

<!-- Right Column: Form -->
<div class="bg-neutral-subtle dark:bg-[#1a202c] p-8 rounded-xl border border-gray-100 dark:border-gray-800 shadow-sm">
<h2 class="text-xl font-semibold text-gray-900 dark:text-white mb-6">Send us a message</h2>
<form action="api/contact-form.php" class="space-y-6" method="POST">
<div class="grid grid-cols-1 md:grid-cols-2 gap-6">
<div class="group">
<label class="block text-sm font-medium leading-6 text-gray-900 dark:text-gray-300 mb-2" for="first-name">First name</label>
<input autocomplete="given-name" class="block w-full rounded-md border-0 py-2.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-primary sm:text-sm sm:leading-6 dark:bg-[#111621] dark:ring-gray-700 dark:text-white transition-all bg-white" id="first-name" name="first_name" type="text" required/>
</div>
<div>
<label class="block text-sm font-medium leading-6 text-gray-900 dark:text-gray-300 mb-2" for="last-name">Last name</label>
<input autocomplete="family-name" class="block w-full rounded-md border-0 py-2.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-primary sm:text-sm sm:leading-6 dark:bg-[#111621] dark:ring-gray-700 dark:text-white transition-all bg-white" id="last-name" name="last_name" type="text" required/>
</div>
</div>
<div class="grid grid-cols-1 md:grid-cols-2 gap-6">
<div>
<label class="block text-sm font-medium leading-6 text-gray-900 dark:text-gray-300 mb-2" for="email">Email address</label>
<input autocomplete="email" class="block w-full rounded-md border-0 py-2.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-primary sm:text-sm sm:leading-6 dark:bg-[#111621] dark:ring-gray-700 dark:text-white transition-all bg-white" id="email" name="email" type="email" required/>
</div>
<div>
<label class="block text-sm font-medium leading-6 text-gray-900 dark:text-gray-300 mb-2" for="phone">Phone number</label>
<input autocomplete="tel" class="block w-full rounded-md border-0 py-2.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-primary sm:text-sm sm:leading-6 dark:bg-[#111621] dark:ring-gray-700 dark:text-white transition-all bg-white" id="phone" name="phone" type="tel"/>
</div>
</div>
<div>
<label class="block text-sm font-medium leading-6 text-gray-900 dark:text-gray-300 mb-2" for="subject">Reason for inquiry</label>
<select class="block w-full appearance-none rounded-md border-0 py-2.5 pl-3 pr-10 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-primary sm:text-sm sm:leading-6 dark:bg-[#111621] dark:ring-gray-700 dark:text-white transition-all bg-white" id="subject" name="subject" required>
<option>General Inquiry</option>
<option>Room Reservation</option>
<option>Dining &amp; Restaurant</option>
<option>Event Planning</option>
<option>Other</option>
</select>
</div>
<div>
<label class="block text-sm font-medium leading-6 text-gray-900 dark:text-gray-300 mb-2" for="message">Message</label>
<textarea rows="6" class="block w-full rounded-md border-0 py-2.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-primary sm:text-sm sm:leading-6 dark:bg-[#111621] dark:ring-gray-700 dark:text-white transition-all bg-white" id="message" name="message" required></textarea>
</div>
<button type="submit" class="w-full rounded-lg bg-[#3f3f3f] px-6 py-3 text-sm font-semibold text-white shadow-sm hover:bg-[#2a2a2a] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#3f3f3f] transition-all">
    Send Message
</button>
</form>
</div>
</div>
</div>

<!-- Map Section -->
<?php 
$mapAddress = getPageSection('contact', 'map_address', strip_tags($contactAddress) ?: '123 Rayfield Road, Jos, Plateau State, Nigeria');
?>
<section class="relative w-full h-[500px] mt-12 bg-gray-100 dark:bg-gray-800">
<div class="absolute inset-0 w-full h-full map-container">
<?php if (!empty($googleMapsApiKey)): ?>
<iframe 
    id="contactGoogleMap"
    class="w-full h-full"
    frameborder="0"
    style="border:0"
    allowfullscreen
    loading="lazy"
    referrerpolicy="no-referrer-when-downgrade"
    src="https://www.google.com/maps/embed/v1/place?key=<?= e($googleMapsApiKey) ?>&q=<?= urlencode($mapAddress) ?>">
</iframe>
<?php else: ?>
<div class="w-full h-full flex items-center justify-center text-gray-500 dark:text-gray-400">
<p class="text-center">Map will appear here once Google Maps API key is configured in settings.</p>
</div>
<?php endif; ?>
</div>
<!-- Overlay card for smaller screens or just aesthetic -->
<div class="absolute bottom-6 left-1/2 -translate-x-1/2 bg-white dark:bg-[#1a202c] py-3 px-6 rounded-full shadow-lg border border-gray-200 dark:border-gray-700 flex items-center gap-2 max-w-[90%] w-max pointer-events-none">
<span class="material-symbols-outlined text-amber-700">near_me</span>
<p class="text-sm font-medium text-gray-900 dark:text-white truncate"><?= e($mapAddress) ?></p>
</div>
</section>
</main>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
