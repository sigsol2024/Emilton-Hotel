<?php
/**
 * Homepage - Dynamic Content
 * Peregrine Hotel Rayfield
 */

require_once __DIR__ . '/includes/content-loader.php';

// Load site settings
$siteName = getSiteSetting('site_name', 'Peregrine Hotel Rayfield');
$currencySymbol = getSiteSetting('currency_symbol', '₦');

// Load homepage sections
$heroTitle = getPageSection('index', 'hero_title', 'Experience Jos.');
$heroSubtitle = getPageSection('index', 'hero_subtitle', 'Stay in Comfort.');
$heroDescription = getPageSection('index', 'hero_description', 'A sanctuary of modern luxury in the heart of Rayfield.');
$heroBackground = getPageSection('index', 'hero_background', 'https://lh3.googleusercontent.com/aida-public/AB6AXuB9XXXbQdZQX_DSKfvOFjS6DzDFvRLPTQz11cwQVPId5SiSGjUKHegaIaE99DcfIMUE86x85uuPs3uTi5KVYcCWbsD-_VD2sWtHMHxgeUXXucKFTUp8V-g6CYIJePgR3EDI2EycLJsN_coiLRcxsAqeZDHGA4yDMgl_VRlQCJzcIRrLUkJ8wzYHufaV2H1BmYbF7pKncmCex-k3Q1hc7HoefvfAOMT21Vvsgz5HmiMdsz4zXUk4mvwoqsYA6cLEnPO5Ai_bSmMH5t4');

// About section
$aboutLabel = getPageSection('index', 'about_label', 'Boulevard Hotel Group');
$aboutTitle = getPageSection('index', 'about_title', 'A Refined Stay in the Heart of Rayfield');
$aboutDescription1 = getPageSection('index', 'about_description_1', 'Peregrine Hotel brings world-class hospitality to Jos. Part of the esteemed Boulevard Hotel Group, we offer generous spaces, modern amenities, and a serene atmosphere tailored for both business and leisure travelers seeking a moment of respite.');
$aboutDescription2 = getPageSection('index', 'about_description_2', 'Immerse yourself in elegance where every detail is curated for your comfort. From our signature dining experiences to our plush, tailored suites.');
$aboutImage = getPageSection('index', 'about_image', 'https://lh3.googleusercontent.com/aida-public/AB6AXuBXwfL--8AQE85elH-Wh25m9jRbCtgY2FgmOXTL9ydZHwgmGs3LxjFYOjp4PI73wd73yvIMF61YHb90MD1_XlTfLINbKB1O0TXDSy-8SPDBe0xAc5Kg1non_vCjzI0XPlt-XgOcM8PIrDUagyBBP3ym1sH-n1ogESWv2dOq9nCwgnfV0CidgkGsTfe56nxHYOpX03Z2pI4GEhiXzwfDsLuDQUPuoklZCrcXh-UUoogRhIEnSqH63LE8fWBT9slURc5KAYs8REtcjWc');

// Rooms section
$roomsTitle = getPageSection('index', 'rooms_title', 'Accommodations');
$roomsSubtitle = getPageSection('index', 'rooms_subtitle', 'Designed for tranquility and style. Choose the space that fits your journey.');

// Amenities section
$amenitiesTitle = getPageSection('index', 'amenities_title', 'Premium Amenities');
$amenitiesDescription = getPageSection('index', 'amenities_description', 'We have curated every aspect of your stay to ensure maximum comfort and convenience.');

// CTA section
$ctaTitle = getPageSection('index', 'cta_title', 'Your Perfect Stay in Jos Awaits');
$ctaDescription = getPageSection('index', 'cta_description', 'Experience the perfect blend of luxury, comfort, and Nigerian hospitality. Book directly with us for the best rates.');

// Load rooms for preview (limit to 3 featured or first 3 active)
$allRooms = getRooms(['is_active' => 1]);
$featuredRooms = array_filter($allRooms, function($room) {
    return !empty($room['is_featured']);
});
$previewRooms = !empty($featuredRooms) ? array_slice($featuredRooms, 0, 3) : array_slice($allRooms, 0, 3);
?>
<!DOCTYPE html>
<html class="light" lang="en">
<head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<title><?= e($siteName) ?> | Luxury Hotel in Jos</title>
<!-- Fonts -->
<link href="https://fonts.googleapis.com" rel="preconnect"/>
<link crossorigin="" href="https://fonts.gstatic.com" rel="preconnect"/>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;700;800&amp;family=Playfair+Display:wght@400;600;700&amp;display=swap" rel="stylesheet"/>
<!-- Material Symbols -->
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;display=swap" rel="stylesheet"/>
<!-- Tailwind CSS -->
<script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
<!-- Theme Config -->
<script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        "primary": "#1754cf",
                        "background-light": "#ffffff",
                        "background-dark": "#111621",
                        "text-main": "#0e121b",
                        "accent-black": "#111111",
                    },
                    fontFamily: {
                        "display": ["Plus Jakarta Sans", "sans-serif"],
                        "serif": ["Playfair Display", "serif"],
                    },
                    borderRadius: {"DEFAULT": "0.25rem", "lg": "0.5rem", "xl": "0.75rem", "full": "9999px"},
                },
            },
        }
    </script>
<style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
        h1, h2, h3, h4, h5, h6 { font-family: 'Playfair Display', serif; }
    </style>
</head>
<body class="bg-background-light text-text-main antialiased selection:bg-primary/20">
<div class="relative flex min-h-screen w-full flex-col overflow-x-hidden">
<?php require_once __DIR__ . '/includes/header.php'; ?>

<!-- Hero Section -->
<section class="relative h-[90vh] min-h-[600px] w-full flex items-center justify-center bg-gray-900 mt-20">
<!-- Background Image -->
<div class="absolute inset-0 z-0 h-full w-full bg-cover bg-center bg-no-repeat" style="background-image: linear-gradient(rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.4)), url('<?= e($heroBackground) ?>');">
</div>
<div class="relative z-10 flex flex-col items-center gap-8 px-4 text-center max-w-4xl mx-auto">
<div class="flex flex-col gap-4">
<h1 class="text-white text-5xl md:text-7xl font-bold leading-tight drop-shadow-lg">
    <?= e($heroTitle) ?><br/><span class="italic font-light"><?= e($heroSubtitle) ?></span>
</h1>
<p class="text-white/90 text-lg md:text-xl font-display font-light max-w-2xl mx-auto drop-shadow-md">
    <?= e($heroDescription) ?>
</p>
</div>
<?php 
$heroCtaText = getPageSection('index', 'hero_cta_text', 'Book Your Stay');
$heroCtaLink = getPageSection('index', 'hero_cta_link', 'rooms_&_suites.php');
$heroCta2Text = getPageSection('index', 'hero_cta2_text', 'Explore Our Rooms');
$heroCta2Link = getPageSection('index', 'hero_cta2_link', 'rooms_&_suites.php');
?>
<div class="flex flex-wrap gap-4 justify-center mt-4 items-center">
<a href="<?= e($heroCtaLink) ?>" class="h-12 px-8 rounded-lg bg-accent-black text-white text-base font-bold transition-all hover:bg-black hover:scale-105 border border-transparent shadow-lg flex items-center justify-center">
    <?= e($heroCtaText) ?>
</a>
<a href="<?= e($heroCta2Link) ?>" class="h-12 px-8 rounded-lg bg-transparent text-white text-base font-bold transition-all hover:bg-white/10 border border-white backdrop-blur-sm flex items-center justify-center">
    <?= e($heroCta2Text) ?>
</a>
</div>
</div>
<!-- Booking Widget: desktop = bridged/overlaid -->
<div class="hidden md:block absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1/2 w-full max-w-5xl px-4 z-20">
<div class="mx-auto rounded-xl bg-white p-4 shadow-2xl border border-gray-100/50">
<form class="flex flex-row gap-0 items-center" action="rooms_&_suites.php" method="GET">
<!-- Check In -->
<div class="flex-1 flex flex-col px-4 md:border-r border-gray-200">
<label class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Check In</label>
<div class="flex items-center gap-2">
<span class="material-symbols-outlined text-gray-400 text-lg">calendar_today</span>
<input class="w-full border-none p-0 text-text-main focus:ring-0 placeholder:text-gray-800 font-medium font-display bg-transparent text-sm" placeholder="Add date" type="date" name="checkin"/>
</div>
</div>
<!-- Check Out -->
<div class="flex-1 flex flex-col px-4 md:border-r border-gray-200">
<label class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Check Out</label>
<div class="flex items-center gap-2">
<span class="material-symbols-outlined text-gray-400 text-lg">calendar_today</span>
<input class="w-full border-none p-0 text-text-main focus:ring-0 placeholder:text-gray-800 font-medium font-display bg-transparent text-sm" placeholder="Add date" type="date" name="checkout"/>
</div>
</div>
<!-- Guests -->
<div class="flex-1 flex flex-col px-4 md:border-r border-gray-200">
<label class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Guests</label>
<div class="flex items-center gap-2">
<span class="material-symbols-outlined text-gray-400 text-lg">group</span>
<select class="w-full border-none p-0 text-text-main focus:ring-0 font-medium font-display bg-transparent text-sm cursor-pointer" name="guests">
<option value="2">2 Adults, 0 Children</option>
<option value="1">1 Adult, 0 Children</option>
<option value="3">2 Adults, 1 Child</option>
</select>
</div>
</div>
<!-- Room Type -->
<div class="flex-1 flex flex-col px-4">
<label class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Room Type</label>
<div class="flex items-center gap-2">
<span class="material-symbols-outlined text-gray-400 text-lg">bed</span>
<select class="w-full border-none p-0 text-text-main focus:ring-0 font-medium font-display bg-transparent text-sm cursor-pointer" name="room_type">
<option value="">Standard Room</option>
<option value="executive">Executive Suite</option>
<option value="presidential">Presidential Suite</option>
</select>
</div>
</div>
<!-- Search Button -->
<div class="p-2">
<button type="submit" class="w-full md:w-auto h-12 md:h-14 px-8 rounded-lg bg-[#3f3f3f] text-white font-bold flex items-center justify-center gap-2 hover:bg-[#2a2a2a] transition-colors">
<span class="material-symbols-outlined">search</span>
<span class="md:hidden">Search</span>
</button>
</div>
</form>
</div>
</div>
</section>

<!-- Booking Widget: mobile = separate section (normal flow) -->
<section class="md:hidden bg-white py-8 px-4 relative -mt-16 z-30">
<div class="mx-auto max-w-5xl rounded-xl bg-white p-4 shadow-2xl border border-gray-100/50">
<form class="flex flex-col gap-4" action="rooms_&_suites.php" method="GET">
<!-- Check In -->
<div class="flex-1 flex flex-col px-4 border-b border-gray-200 pb-4">
<label class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Check In</label>
<div class="flex items-center gap-2">
<span class="material-symbols-outlined text-gray-400 text-lg">calendar_today</span>
<input class="w-full border-none p-0 text-text-main focus:ring-0 placeholder:text-gray-800 font-medium font-display bg-transparent text-sm" placeholder="Add date" type="date" name="checkin"/>
</div>
</div>
<!-- Check Out -->
<div class="flex-1 flex flex-col px-4 border-b border-gray-200 pb-4">
<label class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Check Out</label>
<div class="flex items-center gap-2">
<span class="material-symbols-outlined text-gray-400 text-lg">calendar_today</span>
<input class="w-full border-none p-0 text-text-main focus:ring-0 placeholder:text-gray-800 font-medium font-display bg-transparent text-sm" placeholder="Add date" type="date" name="checkout"/>
</div>
</div>
<!-- Guests -->
<div class="flex-1 flex flex-col px-4 border-b border-gray-200 pb-4">
<label class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Guests</label>
<div class="flex items-center gap-2">
<span class="material-symbols-outlined text-gray-400 text-lg">group</span>
<select class="w-full border-none p-0 text-text-main focus:ring-0 font-medium font-display bg-transparent text-sm cursor-pointer" name="guests">
<option value="2">2 Adults, 0 Children</option>
<option value="1">1 Adult, 0 Children</option>
<option value="3">2 Adults, 1 Child</option>
</select>
</div>
</div>
<!-- Room Type -->
<div class="flex-1 flex flex-col px-4 pb-4">
<label class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Room Type</label>
<div class="flex items-center gap-2">
<span class="material-symbols-outlined text-gray-400 text-lg">bed</span>
<select class="w-full border-none p-0 text-text-main focus:ring-0 font-medium font-display bg-transparent text-sm cursor-pointer" name="room_type">
<option value="">Standard Room</option>
<option value="executive">Executive Suite</option>
<option value="presidential">Presidential Suite</option>
</select>
</div>
</div>
<!-- Search Button -->
<div class="p-2 pt-0">
<button type="submit" class="w-full h-12 px-8 rounded-lg bg-[#3f3f3f] text-white font-bold flex items-center justify-center gap-2 hover:bg-[#2a2a2a] transition-colors">
<span class="material-symbols-outlined">search</span>
<span>Search</span>
</button>
</div>
</form>
</div>
</section>

<!-- About Section -->
<section class="pt-32 pb-20 px-4 sm:px-6 lg:px-8 bg-white">
<div class="mx-auto max-w-7xl">
<div class="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
<div class="flex flex-col gap-8 order-2 lg:order-1">
<div class="space-y-4">
<span class="text-amber-700 font-bold tracking-widest text-xs uppercase"><?= e($aboutLabel) ?></span>
<h2 class="text-4xl md:text-5xl font-serif text-accent-black leading-tight">
    <?= e($aboutTitle) ?>
</h2>
<p class="text-gray-600 text-lg leading-relaxed font-light">
    <?= e($aboutDescription1) ?>
</p>
<p class="text-gray-600 text-lg leading-relaxed font-light">
    <?= e($aboutDescription2) ?>
</p>
</div>
<?php 
$aboutCtaText = getPageSection('index', 'about_cta_text', 'Learn More About Us');
$aboutCtaLink = getPageSection('index', 'about_cta_link', 'about_us.php');
?>
<div class="flex gap-4">
<a class="group flex items-center gap-2 text-accent-black font-bold hover:text-amber-700 transition-colors" href="<?= e($aboutCtaLink) ?>">
    <?= e($aboutCtaText) ?> 
    <span class="material-symbols-outlined text-lg transition-transform group-hover:translate-x-1">arrow_forward</span>
</a>
</div>
</div>
<div class="order-1 lg:order-2 h-[500px] w-full rounded-xl overflow-hidden shadow-2xl relative group">
<div class="absolute inset-0 bg-black/10 transition-opacity group-hover:bg-black/0"></div>
<div class="h-full w-full bg-cover bg-center transition-transform duration-700 group-hover:scale-105" style="background-image: url('<?= e($aboutImage) ?>');">
</div>
</div>
</div>
</div>
</section>

<!-- Rooms Preview -->
<section class="py-20 px-4 sm:px-6 lg:px-8 bg-[#f8f9fc]">
<div class="mx-auto max-w-7xl flex flex-col gap-12">
<div class="flex flex-col md:flex-row justify-between items-end gap-6">
<div class="max-w-2xl">
<h2 class="text-3xl md:text-4xl font-serif text-accent-black mb-4"><?= e($roomsTitle) ?></h2>
<p class="text-gray-600 text-lg font-light"><?= e($roomsSubtitle) ?></p>
</div>
<?php 
$roomsCtaText = getPageSection('index', 'rooms_cta_text', 'View All Rooms');
$roomsCtaLink = getPageSection('index', 'rooms_cta_link', 'rooms_&_suites.php');
?>
<a class="hidden md:flex h-10 px-6 items-center rounded-lg border border-gray-300 text-sm font-bold text-accent-black hover:bg-gray-50 hover:border-gray-400 transition-colors" href="<?= e($roomsCtaLink) ?>"><?= e($roomsCtaText) ?></a>
</div>
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
<?php foreach ($previewRooms as $room): 
    $imageUrl = !empty($room['main_image']) ? $room['main_image'] : '';
    if ($imageUrl && strpos($imageUrl, 'http') !== 0) {
        $imageUrl = (defined('SITE_URL') ? SITE_URL : '') . ltrim($imageUrl, '/');
    }
    $badge = !empty($room['is_featured']) ? 'Most Popular' : '';
?>
<div class="group flex flex-col bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
<div class="h-64 w-full bg-cover bg-center relative" style="background-image: url('<?= e($imageUrl) ?>');">
<?php if ($badge): ?>
<div class="absolute top-4 right-4 bg-white/90 backdrop-blur px-3 py-1 rounded text-xs font-bold uppercase tracking-wider"><?= e($badge) ?></div>
<?php endif; ?>
</div>
<div class="p-6 flex flex-col gap-3 flex-1">
<h3 class="text-xl font-bold font-serif text-accent-black"><?= e($room['title']) ?></h3>
<p class="text-gray-500 text-sm line-clamp-2"><?= e($room['short_description'] ?? '') ?></p>
<div class="mt-auto pt-4 flex items-center justify-between border-t border-gray-100">
<div>
<span class="text-xs text-gray-500">From</span>
<p class="font-bold text-[#3f3f3f] text-lg"><?= e($currencySymbol) ?><?= number_format((float)($room['price'] ?? 0), 0) ?> <span class="text-xs font-normal text-gray-500">/night</span></p>
</div>
<a href="room_details.php?slug=<?= e($room['slug']) ?>" class="h-8 px-4 rounded bg-gray-100 text-xs font-bold text-accent-black hover:bg-gray-200">Details</a>
</div>
</div>
</div>
<?php endforeach; ?>
</div>
<div class="md:hidden flex justify-center mt-4">
<a class="h-12 px-8 flex items-center rounded-lg bg-white border border-gray-300 text-sm font-bold text-accent-black shadow-sm" href="<?= e($roomsCtaLink) ?>"><?= e($roomsCtaText) ?></a>
</div>
</div>
</section>

<!-- Amenities Section -->
<section class="py-20 px-4 sm:px-6 lg:px-8 bg-white">
<div class="mx-auto max-w-7xl flex flex-col lg:flex-row gap-16">
<div class="lg:w-1/3 flex flex-col gap-6">
<h2 class="text-3xl md:text-4xl font-serif text-accent-black"><?= e($amenitiesTitle) ?></h2>
<p class="text-gray-600 font-light text-lg">
    <?= e($amenitiesDescription) ?>
</p>
<?php 
$amenitiesCtaText = getPageSection('index', 'amenities_cta_text', 'View All Amenities');
$amenitiesCtaLink = getPageSection('index', 'amenities_cta_link', 'amenities.php');
?>
<a class="text-amber-700 font-bold text-sm hover:underline" href="<?= e($amenitiesCtaLink) ?>"><?= e($amenitiesCtaText) ?></a>
</div>
<div class="lg:w-2/3 grid grid-cols-2 md:grid-cols-3 gap-px bg-gray-100 border border-gray-100 rounded-xl overflow-hidden">
<?php
// Load amenities from page sections or use defaults
$amenitiesList = getPageSection('index', 'amenities_list', '');
$amenitiesArray = [];
if (!empty($amenitiesList)) {
    $amenitiesArray = json_decode($amenitiesList, true) ?: [];
}
// Default amenities if none set
if (empty($amenitiesArray)) {
    $amenitiesArray = [
        ['icon' => 'wifi', 'title' => 'High-Speed Wi-Fi'],
        ['icon' => 'pool', 'title' => 'Swimming Pool'],
        ['icon' => 'restaurant', 'title' => 'Fine Dining'],
        ['icon' => 'fitness_center', 'title' => 'Fitness Center'],
        ['icon' => 'room_service', 'title' => '24/7 Room Service'],
        ['icon' => 'local_parking', 'title' => 'Secure Parking'],
    ];
}
foreach ($amenitiesArray as $amenity):
    $icon = $amenity['icon'] ?? 'check_circle';
    $title = $amenity['title'] ?? '';
?>
<div class="bg-white p-8 flex flex-col items-center justify-center gap-4 text-center hover:bg-gray-50 transition-colors group">
<span class="material-symbols-outlined text-4xl text-gray-400 group-hover:text-amber-700 transition-colors"><?= e($icon) ?></span>
<span class="font-bold text-sm text-accent-black"><?= e($title) ?></span>
</div>
<?php endforeach; ?>
</div>
</div>
</section>

<!-- Final CTA -->
<section class="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50 border-t border-gray-100">
<div class="mx-auto max-w-4xl text-center flex flex-col items-center gap-8">
<h2 class="text-4xl md:text-5xl font-serif text-accent-black"><?= e($ctaTitle) ?></h2>
<p class="text-gray-600 text-lg font-light max-w-xl">
    <?= e($ctaDescription) ?>
</p>
<?php 
$ctaButtonText = getPageSection('index', 'cta_button_text', 'Book Your Stay');
$ctaButtonLink = getPageSection('index', 'cta_button_link', 'rooms_&_suites.php');
?>
<a href="<?= e($ctaButtonLink) ?>" class="h-14 px-10 rounded-lg bg-accent-black text-white text-lg font-bold transition-all hover:bg-black hover:scale-105 shadow-xl shadow-gray-200 flex items-center justify-center">
    <?= e($ctaButtonText) ?>
</a>
</div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
